# Bookfolloxa Game - Telegram Mini App

## نظرة عامة
لعبة إدارة وكالة مؤثرين على تيليجرام مع تكامل كامل مع منصة Bookfolloxa لزيادة المتابعين.

## الميزات الرئيسية
- 🎮 **Tap-to-Earn**: انقر لكسب متابعين و BFLX
- 👥 **إدارة المؤثرين**: وظّف وطوّر مؤثرين افتراضيين
- 💰 **دخل سلبي**: اكسب BFLX تلقائياً من مؤثريك
- ⚡ **نظام الطاقة**: طاقة تتجدد تلقائياً
- 📋 **الحملات**: أكمل حملات لمكافآت ضخمة
- ✅ **المهام**: مهام يومية واجتماعية
- 🏆 **نظام المستويات**: تقدم وترقيات

## التقنيات المستخدمة
- HTML5
- CSS3 (مع تصميم Bookfolloxa)
- JavaScript (Vanilla)
- Telegram Web App API
- LocalStorage للحفظ

## هيكل الملفات
```
bookfolloxa_webapp/
├── index.html          # الواجهة الرئيسية
├── style.css           # التصميم (بطابع Bookfolloxa)
├── game.js             # منطق اللعبة
├── assets/             # الصور والأيقونات
│   ├── coin.png
│   ├── followers.png
│   ├── default-avatar.png
│   └── influencer-character.png
└── README.md           # هذا الملف
```

## خطوات النشر

### 1. إعداد الملفات
قم بإنشاء مجلد `assets` وإضافة الصور التالية:
- `coin.png` - أيقونة عملة BFLX
- `followers.png` - أيقونة المتابعين
- `default-avatar.png` - صورة افتراضية للمستخدم
- `influencer-character.png` - شخصية المؤثر الرئيسية

### 2. النشر على Replit
1. افتح [Replit](https://replit.com)
2. أنشئ Repl جديد (HTML/CSS/JS)
3. ارفع جميع الملفات
4. شغّل المشروع
5. انسخ رابط الـ URL

### 3. النشر على GitHub Pages
1. أنشئ repository جديد على GitHub
2. ارفع جميع الملفات
3. اذهب إلى Settings > Pages
4. اختر branch: main
5. احفظ وانتظر النشر
6. انسخ الرابط

### 4. النشر على Vercel
1. افتح [Vercel](https://vercel.com)
2. اربط حساب GitHub
3. استورد المشروع
4. انشر
5. انسخ الرابط

### 5. ربط البوت بالتطبيق
بعد نشر التطبيق، أضف الكود التالي لبوت تيليجرام:

```python
from telegram import Update, WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

# رابط التطبيق المنشور
WEBAPP_URL = "https://your-app-url.com"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton(
            "🎮 Play Game",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🎉 Welcome to Bookfolloxa!\n\n"
        "Build your influencer empire and earn BFLX!\n\n"
        "Click the button below to start playing:",
        reply_markup=reply_markup
    )

def main():
    app = Application.builder().token("YOUR_BOT_TOKEN").build()
    app.add_handler(CommandHandler("start", start))
    app.run_polling()

if __name__ == '__main__':
    main()
```

## التخصيص

### تغيير الألوان
عدّل المتغيرات في `style.css`:
```css
:root {
    --primary-bg: #0a0e27;
    --accent-cyan: #00d9ff;
    --accent-purple: #7c3aed;
    --accent-pink: #ff6b9d;
}
```

### تعديل قيم اللعبة
عدّل في `game.js`:
```javascript
let gameState = {
    bflx: 1000,           // الرصيد الابتدائي
    tapPower: 5,          // قوة النقرة
    maxEnergy: 1000,      // الطاقة القصوى
    // ...
};
```

## التكامل مع Backend

لربط اللعبة بـ backend حقيقي، استبدل `localStorage` بـ API calls:

```javascript
// بدلاً من localStorage
async function saveGameState() {
    await fetch('/api/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gameState)
    });
}

async function loadGameState() {
    const response = await fetch('/api/load');
    gameState = await response.json();
}
```

## المهام التالية

### قريباً:
- [ ] نظام الحملات الكامل
- [ ] Leaderboards
- [ ] نظام الإحالة
- [ ] NFTs
- [ ] تكامل Solana Wallet

### مستقبلاً:
- [ ] نظام الفرق/الوكالات
- [ ] السوق (Marketplace)
- [ ] الأحداث الموسمية
- [ ] Mini-games إضافية

## الدعم
للمساعدة أو الاستفسارات، تواصل عبر:
- Telegram: @bookfolloxa
- Website: https://bookfolloxa.com

## الترخيص
جميع الحقوق محفوظة © 2025 Bookfolloxa
