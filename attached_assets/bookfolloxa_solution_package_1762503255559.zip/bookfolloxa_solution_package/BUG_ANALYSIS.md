# 🐛 Bookfolloxa Bot - Critical Bug Analysis

## Executive Summary

The Bookfolloxa Telegram bot has **critical initialization and architecture issues** preventing it from running properly on Railway. The main problems are:

1. **Global Variable Initialization Issue**: `telegram_app = None` causes `AttributeError` when Flask routes try to use it
2. **Event Loop Conflicts**: Mixing Flask (synchronous) with Telegram Bot API (asynchronous) causes runtime errors
3. **Gunicorn Multi-Worker Issue**: Railway uses Gunicorn with 2 workers, but the bot initialization happens in `main()` which doesn't run under Gunicorn
4. **Database Tables Not Created**: Because `main()` never executes, `init_db()` is never called

---

## 🔴 Critical Issues Identified

### Issue #1: Bot Initialization Never Happens with Gunicorn

**Problem Location**: Lines 1511-1538

```python
def main():
    global telegram_app
    import asyncio
    
    logger.info("Initializing database...")
    init_db()  # ❌ This never runs!
    
    logger.info("Initializing bot...")
    telegram_app = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()  # ❌ Never executes!
    
    # ... rest of initialization

if __name__ == '__main__':
    main()  # ❌ Never called when running with Gunicorn!
```

**Why It Fails**:
- Railway runs the app with: `gunicorn --bind 0.0.0.0:$PORT --workers 2 main:app`
- This imports `app` from `main.py` but **never calls `main()`**
- The `if __name__ == '__main__'` block only runs when executing `python main.py` directly
- Result: `telegram_app` stays `None`, database tables are never created

---

### Issue #2: AttributeError in Payment System

**Problem Location**: Line 1080

```python
@app.route('/api/create_invoice', methods=['POST'])
def create_invoice():
    # ...
    result = new_loop.run_until_complete(
        telegram_app.bot.create_invoice_link(  # ❌ telegram_app is None!
            title=pkg['name'],
            # ...
        )
    )
```

**Error Message**:
```
AttributeError: 'NoneType' object has no attribute 'bot'
```

**Root Cause**: `telegram_app = None` (line 1422) is never changed because `main()` never runs.

---

### Issue #3: Event Loop Architecture Conflicts

**Problem**: The code tries to run async Telegram bot operations inside Flask routes (synchronous context), creating multiple event loops in different threads.

**Problematic Pattern** (lines 1070-1094):
```python
def create_invoice_sync():
    """Create invoice in a new thread with its own event loop"""
    new_loop = asyncio.new_event_loop()  # ⚠️ Creating new loops everywhere
    asyncio.set_event_loop(new_loop)
    try:
        result = new_loop.run_until_complete(
            telegram_app.bot.create_invoice_link(...)
        )
    finally:
        new_loop.close()
```

This pattern is repeated in:
- `create_invoice()` route (line 1070)
- `webhook()` route (line 1445)
- Multiple other async operations

**Issues**:
- Event loop conflicts between Flask, Gunicorn workers, and Telegram bot
- Race conditions with multiple workers
- Unpredictable behavior with async context switching

---

### Issue #4: Webhook vs Polling Confusion

**Problem**: The code is set up for **webhook mode** but Railway deployment doesn't guarantee the webhook will be set up before Flask starts accepting requests.

**Setup Flow** (lines 1526-1535):
```python
logger.info("Setting up webhook...")
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.run_until_complete(setup_webhook(telegram_app))  # ❌ Never runs with Gunicorn
loop.close()

logger.info("Starting Flask server with webhook mode...")
app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
```

**Result**: Webhook is never configured, Telegram can't send updates to the bot.

---

## 🔧 Root Cause Summary

| Issue | Root Cause | Impact |
|-------|-----------|--------|
| **Bot Not Initialized** | `main()` never called by Gunicorn | `telegram_app = None` → All bot operations fail |
| **Database Tables Missing** | `init_db()` never called | `users` table doesn't exist → All DB operations fail |
| **Payment System Broken** | `telegram_app.bot` is `None` | Cannot create Telegram Stars invoices |
| **Webhook Not Set** | `setup_webhook()` never called | Telegram can't send updates to bot |
| **Event Loop Conflicts** | Multiple event loops in Flask workers | Unpredictable async behavior |

---

## ✅ Solution Architecture

### Recommended Fix: Initialize at Module Level

Instead of initializing in `main()`, initialize when the module is imported:

```python
# At module level (after imports)
logger.info("🚀 Initializing Bookfolloxa bot...")

# Initialize database
init_db()
logger.info("✅ Database initialized")

# Initialize Telegram bot
telegram_app = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()
logger.info("✅ Telegram bot initialized")

# Setup webhook on first import
import asyncio
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.run_until_complete(setup_webhook(telegram_app))
loop.close()
logger.info("✅ Webhook configured")
```

**Why This Works**:
- Gunicorn imports `main.py` to get the `app` object
- Module-level code runs during import
- Each worker gets its own initialized `telegram_app`
- Database tables are created before any requests arrive

---

## 🎯 Implementation Plan

1. **Move initialization to module level** (before `app` definition)
2. **Remove `main()` function** (no longer needed)
3. **Simplify async operations** (use a single shared event loop per worker)
4. **Add proper error handling** for initialization failures
5. **Add health check endpoint** to verify bot is ready

---

## 📊 Expected Results After Fix

✅ Database tables created automatically on first deployment  
✅ `telegram_app` properly initialized in all Gunicorn workers  
✅ Telegram Stars payment system working  
✅ Webhook properly configured with Telegram  
✅ No more `AttributeError: 'NoneType' object has no attribute 'bot'`  
✅ Bot responds to `/start` command  
✅ Game interface loads correctly  

---

**Next Step**: Implement the fixed version of `main.py` with proper initialization architecture.
